# Red/Green Boomerang Model

Builds an alternate-asset SoH `.o2r` that keeps the normal SoH boomerang geometry and changes only display-list material colors.

Output:

- `dist/soh_red_green_boomerang_model.o2r`
- `dist/soh_betastyleboomerang.o2r`

Covered resources:

- `objects/gameplay_keep/gBoomerangDL` - thrown/world boomerang
- `objects/object_link_child/gLinkChildLeftFistAndBoomerangNearDL` - Link held boomerang, near LOD
- `objects/object_link_child/gLinkChildLeftFistAndBoomerangFarDL` - Link held boomerang, far LOD
- `objects/object_gi_boomerang/gGiBoomerangDL` - get-item boomerang model
- `textures/icon_item_static/gItemIconBoomerangTex` - inventory/equipment icon from `soh_overdumpicons`

The body material is recolored from yellow/orange to red. The reddish/pink crystal material is recolored to green.

No geometry, physics, or item behavior is changed.

Preview/report files:

- `reports/material_recolors.csv`
- `reports/included_icons.csv`
- `previews/red_green_boomerang_material_swatches.png`

Build:

```powershell
python D:\Copilot_OOT\WorkFolders\soh_red_boomerang\build_red_boomerang_o2r.py
```
