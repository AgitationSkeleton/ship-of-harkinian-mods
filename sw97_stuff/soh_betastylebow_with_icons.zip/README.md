# SoH Held Bow Recolor

Alt-asset `.o2r` recolor for the held Fairy Bow model resources.

## Outputs

- `dist/soh_bow_recolor_held.o2r`
  - Recolors the held bow display-list material colors.
  - Also recolors the shared normal arrow shaft red bands to off-white so the arrow visible while aiming matches the bow recolor.
- `dist/soh_betastylebow.o2r`
  - Same contents as `soh_bow_recolor_held.o2r`.
- `dist/soh_bow_recolor_held_bow_only.o2r`
  - Recolors only the held bow display-list material colors.
  - Leaves the shared arrow shaft texture untouched.

## Color Changes

- Bow tan/yellow material -> reddish-brown.
- Bow blue material -> green.
- Bow red material -> off-white.
- Main variant only: normal arrow shaft red bands -> off-white.
- Includes the beta-style bow inventory icons from `soh_overdumpicons`.

## Resources

- `alt/objects/object_link_boy/gLinkAdultRightHandHoldingBowNearDL`
- `alt/objects/object_link_boy/gLinkAdultRightHandHoldingBowFarDL`
- `alt/objects/object_link_boy/gLinkAdultRightHandHoldingBowFirstPersonDL`
- `alt/objects/gameplay_keep/gArrowShaftTex` in the main variant only.
- `alt/textures/icon_item_static/gItemIconBowTex`
- `alt/textures/icon_item_static/gItemIconBowFireTex`
- `alt/textures/icon_item_static/gItemIconBowIceTex`
- `alt/textures/icon_item_static/gItemIconBowLightTex`
